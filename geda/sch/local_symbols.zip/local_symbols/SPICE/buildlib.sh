#!/bin/bash
gnetlist -g spice-sdb -o err_amp.mod err_amp.sch
gnetlist -g spice-sdb -o delay_line.mod delay_line.sch
gnetlist -g spice-sdb -o dead_time_gen.mod dead_time_gen.sch
gnetlist -g spice-sdb -o transformer.mod transformer.sch
gnetlist -g spice-sdb -o transformer_dual.mod transformer_dual.sch
gnetlist -g spice-sdb -o buck_converter.mod buck_converter.sch

gnetlist -g spice-sdb -o pwm_lib.lib pwm_lib.sch
